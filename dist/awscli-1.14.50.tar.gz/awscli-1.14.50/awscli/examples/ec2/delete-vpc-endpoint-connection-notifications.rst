**To delete an endpoint connection notification**

This example deletes the specified endpoint connection notification.

Command::

  aws ec2 delete-vpc-endpoint-connection-notifications --connection-notification-ids vpce-nfn-008776de7e03f5abc

Output::

  {
    "Unsuccessful": []
  }